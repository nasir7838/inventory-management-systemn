<?php
  $page_title = 'Home Page';
  require_once('includes/load.php');
  if (!$session->isUserLoggedIn(true)) { redirect('index.php', false); }

  // Get data for widgets
  $products_sold   = find_higest_saleing_product('10');
  $recent_products = find_recent_product_added('5');
  $recent_sales    = find_recent_sale_added('5');
?>
<?php include_once('layouts/header.php'); ?>

<div class="row">
  <div class="col-md-12">
 
  </div>
</div>

<div class="row">
  <div class="col-md-12">
    <div class="panel">
      <div class="jumbotron text-center">
        <h1>Welcome User</h1>
        <hr>
        <p>Inventory Management System</p>

      </div>
    </div>
  </div>
</div>

<!-- Dashboard Widgets Section -->
<div class="row">
  <!-- Highest Selling Products -->
  <div class="col-md-4">
    <div class="panel panel-default">
      <div class="panel-heading">
        <strong><span class="glyphicon glyphicon-stats"></span> Highest Selling Products</strong>
      </div>
      <div class="panel-body">
        <table class="table table-striped table-bordered table-condensed">
          <thead>
            <tr>
              <th>Title</th>
              <th>Total Sold</th>
              <th>Total Quantity</th>
            </tr>
          </thead>
          <tbody>
            <?php if (!empty($products_sold)): ?>
              <?php foreach ($products_sold as $product): ?>
                <tr>
                  <td><?php echo remove_junk(first_character($product['name'])); ?></td>
                  <td><?php echo (int)$product['totalSold']; ?></td>
                  <td><?php echo (int)$product['totalQty']; ?></td>
                </tr>
              <?php endforeach; ?>
            <?php else: ?>
              <tr><td colspan="3" class="text-center">No records found.</td></tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <!-- Latest Sales -->
  <div class="col-md-4">
    <div class="panel panel-default">
      <div class="panel-heading">
        <strong><span class="glyphicon glyphicon-shopping-cart"></span> Latest Sales</strong>
      </div>
      <div class="panel-body">
        <table class="table table-striped table-bordered table-condensed">
          <thead>
            <tr>
              <th>#</th>
              <th>Product Name</th>
              <th>Date</th>
              <th>Total Sale</th>
            </tr>
          </thead>
          <tbody>
            <?php if (!empty($recent_sales)): ?>
              <?php foreach ($recent_sales as $recent): ?>
              <tr>
                <td class="text-center"><?php echo count_id(); ?></td>
                <td><?php echo remove_junk(first_character($recent['name'])); ?></td>
                <td><?php echo remove_junk(ucfirst($recent['date'])); ?></td>
                <td>₹<?php echo remove_junk(first_character($recent['price'])); ?></td>
              </tr>
              <?php endforeach; ?>
            <?php else: ?>
              <tr><td colspan="4" class="text-center">No recent sales.</td></tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <!-- Recently Added Products -->
  <div class="col-md-4">
    <div class="panel panel-default">
      <div class="panel-heading">
        <strong><span class="glyphicon glyphicon-plus"></span> Recently Added Products</strong>
      </div>
      <div class="panel-body">
        <div class="list-group">
          <?php if (!empty($recent_products)): ?>
            <?php foreach ($recent_products as $prod): ?>
              <a class="list-group-item clearfix" href="edit_product.php?id=<?php echo (int)$prod['id']; ?>">
                <h4 class="list-group-item-heading">
                  <?php if ($prod['media_id'] === '0'): ?>
                    <img class="img-avatar img-circle" src="uploads/products/no_image.png" alt="">
                  <?php else: ?>
                    <img class="img-avatar img-circle" src="uploads/products/<?php echo $prod['image']; ?>" alt="">
                  <?php endif; ?>
                  <?php echo remove_junk(first_character($prod['name'])); ?>
                  <span class="label label-warning pull-right">₹<?php echo (int)$prod['sale_price']; ?></span>
                </h4>
                <span class="list-group-item-text pull-right"><?php echo remove_junk(first_character($prod['categorie'])); ?></span>
              </a>
            <?php endforeach; ?>
          <?php else: ?>
            <p class="text-center">No recent products.</p>
          <?php endif; ?>
        </div>
      </div>
    </div>
  </div>
</div>

<?php include_once('layouts/footer.php'); ?>